import logic.runAutobaseCycle

fun main() {
    // Вызов функции. Результаты только в консоль.
    runAutobaseCycle()
}
