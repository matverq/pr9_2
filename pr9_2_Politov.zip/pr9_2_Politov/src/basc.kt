package base

// Базовый класс
open class Transport(val brand: String) {
    open fun getDescription() = "Транспорт марки $brand"
}