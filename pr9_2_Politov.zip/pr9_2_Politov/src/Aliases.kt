package base

// Псевдонимы типов
typealias BaseAuto = Transport
typealias CargoAuto = Truck
typealias Staff = Human
typealias Trip = Order