package base

// Независимый класс для персонала
class Human(val name: String, val role: String) {
    var isSuspended: Boolean = false
    var isTripDone: Boolean = false
}