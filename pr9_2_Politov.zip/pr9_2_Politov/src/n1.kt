package base

// Наследник 1
class Truck(brand: String, val capacity: Int) : Transport(brand) {
    var needsRepair: Boolean = false
    override fun getDescription() = "Грузовик $brand (г/п $capacity т). Ремонт: $needsRepair"
}