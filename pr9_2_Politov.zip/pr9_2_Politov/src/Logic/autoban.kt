package logic

import base.* // Импортируем классы и псевдонимы из пакета base
fun runAutobaseCycle() {
    println("===СИСТЕМА АВТОБАЗА===")
    // Создание объектов через псевдонимы
    print("Имя диспетчера: ")
    val dispatcher: Staff = Staff(readln(), "Диспетчер")
    print("Имя водителя: ")
    val driver: Staff = Staff(readln(), "Водитель")
    print("Марка грузовика: ")
    val truck: CargoAuto = CargoAuto(readln(), 15)
    print("Пункт назначения: ")
    val trip: Trip = Trip(readln())
    // Логика взаимодействия
    println("\n[Диспетчер] ${dispatcher.name} назначает рейс в ${trip.destination}...")

    if (driver.isSuspended) {
        println("Ошибка: Водитель отстранен!")
        return
    }
    println("Рейс выполнен? (да/нет):")
    if (readln().lowercase() == "да") {
        driver.isTripDone = true
        println("[Водитель] ${driver.name}: Рейс завершен.")
    }

    println("Нужен ремонт? (да/нет):")
    if (readln().lowercase() == "да") {
        truck.needsRepair = true
        println("[Водитель] Подана заявка на ремонт ${truck.brand}.")

        // Диспетчер отстраняет водителя
        driver.isSuspended = true
        println("[Диспетчер] Водитель ${driver.name} отстранен от работы.")
    }
}