package base

// Наследник 2
class Bus(brand: String, val seats: Int) : Transport(brand)