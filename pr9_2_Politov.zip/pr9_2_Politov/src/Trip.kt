package base

// Независимый класс для заявки
class Order(val destination: String)